$.getJSON("music.json", function(json) {
    console.log(json);
});


$(function(){
        $('.musical-container img').hover(
            function() { 
                $(this).prev()[0].play()
            },
            function() { 
                $(this).prev()[0].pause()
            }
        )
    })

console.log("this is working");



