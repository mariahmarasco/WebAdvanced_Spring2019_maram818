/* To store your JSON file online you can use http://myjson.com/
 You would get a URL and you can make calls to that URL*/

// You could also use https://jsonlint.com/ to valid the formating of your JSON file. 

// The reason why we preffer to use JSON is because is human readable


// JSON - Stans for Java Script Object Noation 




/*

	1. Understanding how to build an object and call information inside the object.

*/



// VANILLA JAVASCRIPT

//var myData = {"firstName":"Karla", "lastName":"Polo", "age":"29"}; // Here, I'm creating an object. You can create objects right here, but it's not best practice.
//console.log(myData);

//document.getElementById("json-container").innerHTML = myData.firstName // Here, I'm adding the object I created into the HTML id "json-container".



// JQUERY

//$(".json-container").append(myData.firstName + " " + myData.lastName); // This "append" is looking for a class, and will append everything with that class.
//$("#json-container").html(myData.lastName); // This "html" is looking for an ID within the html. "html" doesn't work with classes, only IDs.



/*

	2. creating a data set that contains an array of objects

*/

/*
var myData = {"people": [	
							{"firstName":"Karla", "lastName":"Polo", "hobbies":[{"hobby1":"Skating"}, {"hobby2":"Running"}]},
							{"firstName":"James", "lastName":"Smith", "hobbies":[{"hobby1":"Rowing"}, {"hobby2":"Cooking"}]},
							{"firstName":"Sinead", "lastName":"Jackson", "hobbies":[{"hobby1":"Dancing"}, {"hobby2":"Football"}]}
						]}
// console.log(myData);
*/


/*
// Why is this not working?
$("#json-container").append(myData.people[1].firstName + " " + myData.people[2].hobbies[0]);
/*



 /*

	3. Stringify the JSON Data and converting it back to JSON format. 

*/



// var stringpeople = JSON.stringify(myData);
// console.log(stringpeople);

// $("#json-container").append(stringpeople);



// The opposite of "stringify" is "parse". Here we're parsing what we previously stringified.
// Whenever you want to convert a string of text, the "parse" built-in function will convert it into a JSON object
// However, when you use "append", it won't print to the page like stringify, because the data needs to be displayed in a different way.

// var parsepeople = JSON.parse(stringpeople);
// console.log(parsepeople);

// $("#json-container").append(parsepeople);


 



 /*

	4. Understanding for loops and pulling data from a json file.

*/
	

/*
$.getJSON("../data.json", function(data){ // ".." is shorthand for "go backout of the current directory, and go here instead".
// $.getJSON("https://api.myjson.com/bins/1a175s", function(data){      <--- This is accessing the same information, but stored online!

											// "data" is a temporary argument which will be replaced later.

			var myUsers = data.people;
			console.log(myUsers);


			$.each(data.people, function(index, key) { 	// "each" is a for loop. It's the way that we create for loops woth JSON files, and allows you to look through objects.
														// Normally in for loops, we use "i" which stands for index. Here, we're saying index doiectly.
														// "key" refers to the set of attributes, eg. firstName, lastName, hobbies, etc.
				console.log(key);


				$("#json-container").append(key.firstName + "<br>"); // Here, I'm appending the document with all of the firstNames from my JSON container.

			});

			

})
*/








/*

	5. Making ajax calls and pulling information from JSON files stored online. 

*/





/*

	6. Get information from an API 

	you can get a list of public API at: https://github.com/toddmotto/public-apis
	today we're going to use a Jokes api -  http://www.icndb.com/api/

*/



$(document).ready(function() { // When my page loads, I want to trigger the following function.


	$("#btn").click(function() {




		// When I click my button, this should happen.

		// var accessToken = '19865897.1677ed0.6eab135b9a724bd3aa168426cd053c64'; Use this if you need an API with a token

		$.getJSON("http://api.open-notify.org/astros.json", function(data) { // API that shows how many people are currently in outer space

			console.log(data['number']) // This will log the current # of people in outer space


			$.each(data.data, function(index, key) { // The first data comes from our .getJSON line, the second comes directly from the API.
				
				console.log(data);

				$("#json-container").append(key.user.name + "<br>" + "<img src =" + key.image_url["320wx320h"] + ">" + "<br>")
				// The above code is getting 

			})


		})



	})
})






/*

	7. Get information from another API 

	you can get a list of public API at: https://github.com/toddmotto/public-apis
	today we're going to use a Jokes api -  https://www.mixcloud.com/developers/

*/	


	












